### Karderia

Karderia is a game made by Boijy. More details can be found on https://main--karderiawebsite.netlify.app/!

# How to run the game?

1. Extract Karderia.zip file you just downloaded

2. Make sure you extracted all the files

3. Double click Karderia.exe

4. Enjoy!

# Who made the game?

Boijy - Made the website and the game. Contact him by emailing kinsoobiao@gmail.com.

## Short game walkthrough in development

When I started making this game, I planned it to be something like collection card
game on C#. But after some time I decided to make it something similar to RPG.
I started with making the cards: it was not really easy. But after 2 days I had a
working cards being drawn. After that, I made a first-move chooser after and the 
field between the cards. There were 2 lists: first for player cards and second for 
AI cards. The cards were generated randomly, like it is now. I added an enum too:
that's for card types. Next I added move handling: each move you and AI are given 
+10 mana and the moves are changing. I made separate classes for both AI and the player,
featuring current mana. For player I added the "CharacterName" variable, which is for 
now handling the name changing system. To be honest I didn't plan to do anything with it
before, but now it's all set. The next step was rewriting the battle field and card displaying
classes: it was too rushed. I learned lots of new stuff while doing it. 

## What is the game about and why you recommend it?

Karderia is a game for those who love minimalism. The game is still in development and will be
published very soon. The game is written on C# only and is 2D. In this game you are given 3 
random cards, each having a unique type and skills. First move is being decided
randomly. For now, the game can be played against the AI only. When it's your
move, join the battle by placing a card on the table or getting one more
unique card from the deck. AI also does the same, join the battle! Each attack
costs specific mana per card, so watch out and build a strategy! If you don't
have enough mana for all of your current cards, you skip your turn. Each game
gives you some XP, become a 100-level pro and win all the games! Achievements for
your games are coming soon, there might also be a shop and leaderboards!

# When the game was released?

4th August 2024.

## Why did you make this game not on Unity or other engines and pro tools you use?

It's my old game
I used to work on when I just started learning C#. And there was a chance to finish it! And it's done. Why not?

###### MORE INFO CAN BE FOUND IN OUR WEBSITE OR AT OUR HELP SECTION INSIDE THE GAME! HAPPY BATTLING!